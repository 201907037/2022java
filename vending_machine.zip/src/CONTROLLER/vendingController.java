package CONTROLLER;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

import DAO.JDBCConnector;
import DAO.VendingDAO;
import VIEW.inputview;
import VIEW.vendingview;
import VO.VendingVO;

public class vendingController extends JFrame {
	Connection con;
	VendingDAO dao;
	vendingview vendingview;
	inputview inputview;
	ArrayList<VendingVO> voList;
	ArrayList<Integer> quantity;
	String[] iconstr = { "0", "1", "2", "3", "4", "5", "6", "7" };
	JButton[] btnselect;
	JLabel[] jlsoldout;
	ImageIcon[] takeimg;
	JButton[] btninput;
	JTextField[] pricejt;
	JTextField[] quanjt;
	
	int totalamount;
	int cno,cprice;
	JTextField incoin;
	JLabel excount;
	int money;
	int sf;
	int[] flagpossible;
	
	JButton btninsert;
	JButton btnopen;
	JButton btntake;
	JButton btngetex;
	
	JLabel total;
	JButton btntotal;
	JButton close;
	
	public vendingController() {
		con = JDBCConnector.getCon();
		dao=new VendingDAO();
		JPanel cpan = new JPanel();
		CardLayout layout = new CardLayout();
		cpan.setLayout(layout);
		//vendingview
		vendingview = new vendingview();
		voList = dao.select();
		quantity = new ArrayList<Integer>();
		for(int i=0;i<voList.size();i++) {
			quantity.add(voList.get(i).getQuantity());
		}
		vendingview.setVendingVOList(voList);
		vendingview.StringSet();
		vendingview.initview();
		flagpossible = new int[iconstr.length];
		btnselect = new JButton[iconstr.length];
		jlsoldout = new JLabel[iconstr.length];
		for(int i=0;i<iconstr.length;i++) {
			flagpossible[i]=0;
		}
		for(int i=0;i<iconstr.length;i++) {
			btnselect[i] = vendingview.getBtnselect(i);
			jlsoldout[i] = vendingview.getsoldout(i);
			btnselect[i].addActionListener(btnchoose);
		}
		btninsert = vendingview.getBtninsert();
		btnopen = vendingview.getBtnopen();
		btngetex = vendingview.getBtnexchange();
		incoin= vendingview.getcoin();
		excount = vendingview.getexcount();
		btninsert.addActionListener(btninout);
		btngetex.addActionListener(btninout);
		btnopen.addActionListener(btnop);
		
		takeimg = new ImageIcon[iconstr.length];
		for(int i=0;i<iconstr.length;i++) {
			takeimg[i] = new ImageIcon("img/d"+i+".jpg");
		}
		btntake = new JButton();
		btntake.addActionListener(btnT);
		
		//inputview
		inputview = new inputview();
		inputview.setVendingVOList(voList);
		inputview.StringSet();
		inputview.initview();
		btninput = new JButton[iconstr.length];
		pricejt = new JTextField[iconstr.length];
		quanjt = new JTextField[iconstr.length];
		for(int i=0;i<iconstr.length;i++) {
			btninput[i] = inputview.getBtnselect(i);
			pricejt[i] = inputview.getjtprice(i);
			quanjt[i] = inputview.getQuantity(i);
			btninput[i].addActionListener(btnin);
		}
		total = inputview.getTotal();
		btntotal = inputview.getbtnTotal();
		close = inputview.getClose();
		btntotal.addActionListener(btnWD);
		close.addActionListener(btnop);
		
		cpan.add(vendingview);
		cpan.add(inputview);
		add(cpan);
		add(btntake,BorderLayout.SOUTH);
		setTitle("자판기");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(100, 100, 440, 800);
		setVisible(true);
	}

	ActionListener btnchoose = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			//System.out.println("정상작동");
			ArrayList<VendingVO> quan;
			VendingVO quanvo;
			String cname = e.getActionCommand();
			quan=dao.getQuantity(cname);
			quanvo=quan.get(0);
			cno = dao.take(quanvo);
			if(quantity.get(cno)!=0) {
				if(flagpossible[cno]==1) {
				cprice=quanvo.getPrice();
				btntake.setIcon(takeimg[cno]);
				int result=0;
				result = money-cprice;
				totalamount+=cprice;
				total.setText(totalamount+"");
				excount.setText(result+"");
				for(int i=0;i<iconstr.length;i++) {
					btnselect[i].setBackground(Color.red);
					flagpossible[i]=0;
				}
				sf=1;
				}
				
			}
			
		}
	};
	ActionListener btnT = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			btntake.setIcon(null);
			excount.setText("");
			incoin.setText("");
			sf=0;
			voList.clear();
			quantity.clear();
			voList = dao.select();
			//quantity = new ArrayList<Integer>();
			for(int i=0;i<voList.size();i++) {
				quantity.add(voList.get(i).getQuantity());
				if(quantity.get(i)==0) {
					jlsoldout[i].setText("품절");
				}
			}
		}
	};
	ActionListener btninout = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(sf==0) {
			excount.setText("");
			if(e.getSource()==btninsert) {
			voList = dao.select();
			String moneystr = incoin.getText();
			if (moneystr.equals("")) {
				excount.setText("돈을넣으시오");
			}
			else {
			money = Integer.parseInt(moneystr);
			int flag=0;
			int p=0;
			for(int i=0;i<voList.size();i++) {
				VendingVO vo = voList.get(i);
				p=vo.getPrice();
				
				if(p<=money) {
					if(quantity.get(i)!=0) {
					btnselect[i].setBackground(Color.BLUE);
					flagpossible[i]=1;
					}
					
					
				}else {
					flag++;
				}
				if(flag==8) {
					excount.setText(moneystr);
				}
			}
			}
			}
			else if(e.getSource()==btngetex) {
				excount.setText("");
				incoin.setText("");
				for(int i=0;i<iconstr.length;i++) {
					btnselect[i].setBackground(Color.red);
					flagpossible[i]=0;
				}
			}
			
		}
		}
	};
	ActionListener btnop = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			switch (e.getActionCommand()) {
			case "열기":
			{
				vendingview.setVisible(false);
				inputview.setVisible(true);
				
				quantity.clear();
				voList = dao.select();
				for(int i=0;i<iconstr.length;i++) {
					VendingVO vo = voList.get(i);
					quanjt[i].setText(vo.getQuantity()+"");
					pricejt[i].setText(vo.getPrice()+"");
					quantity.add(vo.getQuantity());
				}
				
			}
				break;
			case "닫기":
			{
				vendingview.setVisible(true);
				inputview.setVisible(false);
				voList.clear();
				quantity.clear();
				voList = dao.select();
				for(int i=0;i<iconstr.length;i++) {
					VendingVO vo = voList.get(i);
					jlsoldout[i].setText(vo.getPrice()+"");
					quantity.add(vo.getQuantity());
				}
				
			}
				break;
			default:
				break;
			}
			
		}
	};
	ActionListener btnin = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String name = e.getActionCommand();
			int price=0;
			int quan=0;
			switch (name) {
			case "콜라":
			{
				price = Integer.parseInt(pricejt[0].getText());
				quan = Integer.parseInt(quanjt[0].getText());
				dao.update(name, price, quan);
			}
				break;
			case "사이다":
			{
				price = Integer.parseInt(pricejt[1].getText());
				quan = Integer.parseInt(quanjt[1].getText());
				dao.update(name, price, quan);
			}
				break;
			case "커피":
			{
				price = Integer.parseInt(pricejt[2].getText());
				quan = Integer.parseInt(quanjt[2].getText());
				dao.update(name, price, quan);
			}
				break;
			case "초록매실":
			{
				price = Integer.parseInt(pricejt[3].getText());
				quan = Integer.parseInt(quanjt[3].getText());
				dao.update(name, price, quan);
			}
				break;
			case "하늘보리":
			{
				price = Integer.parseInt(pricejt[4].getText());
				quan = Integer.parseInt(quanjt[4].getText());
				dao.update(name, price, quan);
			}
				break;
			case "데자와":
			{
				price = Integer.parseInt(pricejt[5].getText());
				quan = Integer.parseInt(quanjt[5].getText());
				dao.update(name, price, quan);
			}
				break;
			case "닥터페퍼":
			{
				price = Integer.parseInt(pricejt[6].getText());
				quan = Integer.parseInt(quanjt[6].getText());
				dao.update(name, price, quan);
			}
				break;
			case "망고":
			{
				price = Integer.parseInt(pricejt[7].getText());
				quan = Integer.parseInt(quanjt[7].getText());
				dao.update(name, price, quan);
			}
				break;

			default:
				break;
			}
			
		}
	};
	ActionListener btnWD = new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			totalamount=0;
			total.setText("");
		}
	};
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new vendingController();
	}

}
