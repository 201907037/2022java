/**
 * 
 */
/**
 * @author user
 *
 */
module vending_machine {
	requires java.sql;
	requires java.desktop;
	requires mysql.connector.java;
}