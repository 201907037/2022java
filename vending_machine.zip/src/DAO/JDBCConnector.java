package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class JDBCConnector {
		private static final String DRIVER_PATH = "com.mysql.cj.jdbc.Driver";
		private static final String URL = "jdbc:mysql://127.0.0.1:3306/db2022_201907037?serverTimezone=UTC&useUnicode=yes&characterEncoding=UTF-8";
		private static final String ID = "root";
		private static final String PWD = "1234";
		
		private static Connection con;
		public static Connection getCon() {
			try {
				Class.forName(DRIVER_PATH);
				System.out.println("정상적으로 JDBC가 로드되었습니다.");
				con=DriverManager.getConnection(URL, ID, PWD);
				System.out.println("연결이 잘 되었습니다.");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return con;
		}
		public static void resultSetTest() {
			try {
				Statement stmt = con.createStatement();
				String sql="Select * from stock";
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()) {
					System.out.println(rs.getString("name")+"\t");
					System.out.println(rs.getInt("price")+"\t");
					System.out.println(rs.getInt("quantity")+"\t");
				}
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			getCon();
			resultSetTest();
		}
}
