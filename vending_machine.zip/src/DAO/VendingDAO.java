package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import VO.VendingVO;

public class VendingDAO {
	ArrayList<VendingVO> voList;
	
	public ArrayList<VendingVO> select(){
		Connection con = JDBCConnector.getCon();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		voList=new ArrayList<VendingVO>();
		
		try {
			String sql = "select * from stock;";
			pstmt = con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				VendingVO vo = new VendingVO();
				vo.setNo(rs.getInt("no"));
				vo.setName(rs.getString("name"));
				vo.setPrice(rs.getInt("price"));
				vo.setQuantity(rs.getInt("quantity"));
				voList.add(vo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			try {
				if(rs != null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return voList;
	}

	public void update(String name,int price,int quantity) {
		Connection con = JDBCConnector.getCon();
		PreparedStatement pstmt =null;
		String sql="update stock set price=?,quantity=? where name=?;";
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, price);
			pstmt.setInt(2, quantity);
			pstmt.setString(3, name);
			
			int count = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
					con.close();
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
			}
	}

	public ArrayList<VendingVO> choose(int cno){
		Connection con = JDBCConnector.getCon();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		voList=new ArrayList<VendingVO>();
		try {
			String sql = "select * from stock where no=?;";
			pstmt = con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			pstmt.setInt(1, cno);
			while(rs.next()) {
				VendingVO vo = new VendingVO();
				vo.setNo(rs.getInt("no"));
				vo.setName(rs.getString("name"));
				vo.setPrice(rs.getInt("price"));
				vo.setQuantity(rs.getInt("quantity"));
				voList.add(vo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			try {
				if(rs != null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return voList;
	}
	
	public ArrayList<VendingVO> getQuantity(String cname){
		Connection con = JDBCConnector.getCon();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		voList=new ArrayList<VendingVO>();
		try {
			String sql = "select * from stock where name=?;";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cname);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				VendingVO vo = new VendingVO();
				vo.setNo(rs.getInt("no"));
				vo.setName(rs.getString("name"));
				vo.setPrice(rs.getInt("price"));
				vo.setQuantity(rs.getInt("quantity"));
				voList.add(vo);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			
			try {
				if(rs != null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return voList;
	}
	
	public int take(VendingVO vo) {
		Connection con = JDBCConnector.getCon();
		PreparedStatement pstmt =null;
		int re;
		String sql="update stock set quantity=? where no=?;";
		try {
			pstmt=con.prepareStatement(sql);
			re=vo.getQuantity();
			if(re>0)
			re--;
			pstmt.setInt(1, re);
			pstmt.setInt(2, vo.getNo());
			
			int count = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				if(pstmt!=null)
					pstmt.close();
				if(con!=null)
					con.close();
				} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
			}
		return vo.getNo();
	}
	
}


