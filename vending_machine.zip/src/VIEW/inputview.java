package VIEW;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import VO.VendingVO;

public class inputview extends JPanel {
	ArrayList<VendingVO> voList;
	
	JPanel mainpan = new JPanel(new BorderLayout());
	JPanel centerpan = new JPanel(new GridLayout(6,4));
	JPanel southpan = new JPanel();
	JPanel pan = new JPanel(new GridLayout(2,4));
	
	String[] iconstr = { "0", "1", "2", "3", "4", "5", "6", "7" };
	
	JPanel[] drink=new JPanel[iconstr.length];
	JButton[] btn= new JButton[iconstr.length];
	
	ArrayList<String> btnstr = new ArrayList<String>();
	ArrayList<Integer> pricestr = new ArrayList<Integer>();
	ArrayList<Integer> quantitystr = new ArrayList<Integer>();
	
	JTextField[] pricetf = new JTextField[iconstr.length];
	JTextField[] quantity = new JTextField[iconstr.length];

	JButton close = new JButton("닫기");
	JButton outcoin = new JButton("돈 빼기");
	JLabel totalcoin = new JLabel();
	ArrayList<Integer> quant = new ArrayList<Integer>();
	
	public inputview() {
		totalcoin.setOpaque(true);
		totalcoin.setBackground(Color.white);
		JLabel[] blank = new JLabel[13];
		JLabel[] sblank = new JLabel[3];
		for(int i =0;i<13;i++) {
			blank[i] = new JLabel();
		}
		
		for(int i=0;i<12;i++) {
			centerpan.add(blank[i]);
		}
		
		centerpan.add(close);
		centerpan.add(blank[12]);
		
		for(int i=0;i<2;i++) {
			sblank[i]=new JLabel();
			centerpan.add(sblank[i]);
		}
		centerpan.add(totalcoin);
		centerpan.add(outcoin);
		
		 mainpan.add(centerpan,"Center");
		 mainpan.add(pan,"North");
		
	}
	
	public void StringSet() {
		VendingVO vo=null;
		
		for(int i=0;i<iconstr.length;i++) {
			vo = voList.get(i);
			btnstr.add(vo.getName());
			quantitystr.add(vo.getQuantity());
			pricestr.add(vo.getPrice());
		}
	}
	
	public void initview() {
		for(int i=0;i<iconstr.length;i++) {
			drink[i] = new JPanel(new BorderLayout());
			btn[i] = new JButton(btnstr.get(i));
			btn[i].setBackground(Color.white);
			pricetf[i] = new JTextField();
			pricetf[i].setText(pricestr.get(i)+"");
			quantity[i] = new JTextField(quantitystr.get(i)+"");
			quantity[i].setHorizontalAlignment(JLabel.CENTER);
			drink[i].add("Center", pricetf[i]);
			drink[i].add("North",quantity[i]);
			drink[i].add("South", btn[i]);
			pan.add(drink[i]);
		}
		 add(mainpan);
		
	}
	public void setVendingVOList(ArrayList<VendingVO> voList) {
		this.voList = voList;
	}
	public JButton getBtnselect(int index) {
		return btn[index];
	}
	public JTextField getQuantity(int index) {
		return quantity[index];
	}
	public JLabel getTotal() {
		return totalcoin;
	}
	public JButton getbtnTotal() {
		return outcoin;
	}
	public JTextField getjtprice(int index) {
		return pricetf[index];
	}
	public JButton getClose() {
		return close;
	}
}
