package VIEW;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

import DAO.VendingDAO;
import VO.VendingVO;

public class vendingview extends JPanel {
	ArrayList<VendingVO> voList;
	JPanel mainpan = new JPanel(new BorderLayout());
	JPanel centerpan = new JPanel(new GridLayout(6,4));
	JPanel southpan = new JPanel();
	JPanel pan = new JPanel(new GridLayout(2,4));
	String[] iconstr = { "0", "1", "2", "3", "4", "5", "6", "7" };
	ArrayList<String> btnstr = new ArrayList<String>();
	JPanel[] drink=new JPanel[iconstr.length];
	JLabel[] jl= new JLabel[iconstr.length];
	ImageIcon[] venimg=new ImageIcon[iconstr.length];
	JButton[] btn= new JButton[iconstr.length];
	ArrayList<Integer> pricestr = new ArrayList<Integer>();
	
	JLabel[] price = new JLabel[iconstr.length];

	JButton open = new JButton("열기");
	JButton insertcoin = new JButton("돈 넣기");
	JTextField coin = new JTextField();
	JButton exchange = new JButton("거스름돈");
	JLabel excount = new JLabel("");
	ArrayList<Integer> quant = new ArrayList<Integer>();
	
	
	public vendingview() {
		
		
		excount.setOpaque(true);
		excount.setBackground(Color.white);
		JLabel[] blank = new JLabel[13];
		JLabel[] sblank = new JLabel[3];
		for(int i =0;i<13;i++) {
			blank[i] = new JLabel();
		}
		
		for(int i=0;i<12;i++) {
			centerpan.add(blank[i]);
		}
		
		centerpan.add(open);
		centerpan.add(blank[12]);
		centerpan.add(coin);
		centerpan.add(insertcoin);
		for(int i=0;i<2;i++) {
			sblank[i]=new JLabel();
			centerpan.add(sblank[i]);
		}
		centerpan.add(excount);
		centerpan.add(exchange);
		
		 mainpan.add(centerpan,"Center");
		 mainpan.add(pan,"North");
		
		
	}
	public void StringSet() {
		VendingVO vo=null;
		
		for(int i=0;i<iconstr.length;i++) {
			vo = voList.get(i);
			btnstr.add(vo.getName());
			pricestr.add(vo.getPrice());
			quant.add(vo.getQuantity());
		}
	}

	public void initview() {
		for(int i=0;i<iconstr.length;i++) {
			drink[i] = new JPanel(new BorderLayout());
			venimg[i] = new ImageIcon("img/d" + i + ".jpg");
			jl[i] = new JLabel(venimg[i]);
			btn[i] = new JButton(btnstr.get(i));
			btn[i].setBackground(Color.red);
			if(quant.get(i)==0) {
				price[i] = new JLabel("품절");
			}else {
				price[i] = new JLabel(pricestr.get(i)+"");
			}
			price[i].setHorizontalAlignment(JLabel.CENTER);
			drink[i].add("North", jl[i]);
			drink[i].add("Center",price[i]);
			drink[i].add("South", btn[i]);
			pan.add(drink[i]);
		}
		 add(mainpan);
		
	}
	public void setVendingVOList(ArrayList<VendingVO> voList) {
		this.voList = voList;
	}
	public JButton getBtnselect(int index) {
		return btn[index];
	}
	public JButton getBtninsert() {
		return insertcoin;
	}
	public JButton getBtnopen() {
		return open;
	}
	public JButton getBtnexchange() {
		
		return exchange;
	}
	public JTextField getcoin() {
		return coin;
	}
	public JLabel getexcount() {
		return excount;
	}
	
	public JLabel getsoldout(int index) {
		
		return price[index];
	}
	
	
}
